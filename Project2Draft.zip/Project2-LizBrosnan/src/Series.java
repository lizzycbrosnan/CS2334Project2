import java.util.List;

/**
 * 
 * CS 2334 
 * Project 2
 * 2/19/2016
 * @author Liz Brosnan
 * 
 * This is a class that will store information about TV series. 
 *
 */
public class Series {
	
	/** This variables stores the title of the series. */
	public String seriesTitle;
	
	/** This variable stores the start year of the series. */
	public String seriesStartYear; 
	
	/** This variable stores the duration of the series. (years broadcasted) */
	public String seriesDuration;
	
	/** This ArrayList will eventually store episodes of a specfic show. */
	public List<?> episodes;
	
	/** This is a general constructor for a series object. */
	public Series()
	{
		this.seriesTitle = "";
		this.seriesStartYear = ""; 
		this.seriesDuration = "";
	}
	
	/** This is a constructor for a series object with fields already defined. */ 
	public Series(String seriesTitle, String seriesStartYear, String seriesDuration)
	{
		this.seriesTitle = "";
		this.seriesStartYear = ""; 
		this.seriesDuration = "";
		
	}

	/**
	 * Sets the title of the series.
	 * @param seriesTitle
	 */
	public void setSeriesTitle(String seriesTitle)
	{
		this.seriesTitle = seriesTitle;	
	}
	
	/** 
	 * Sets the start date of the series.
	 * @param seriesStartDate
	 */
	public void setSeriesStartYear(String seriesStartYear)
	{
		this.seriesStartYear = seriesStartYear;
	}
	/**
	 * Sets the duration of the series.
	 * @param seriesDuration
	 */
	public void setSeriesDuration(String seriesDuration)
	{
		this.seriesDuration = seriesDuration;
	}
	
	/**
	 * Returns the title of the series. 
	 * @return String
	 */
	public String getSeriesTitle()
	{
		return seriesTitle;
	}
	
	/**
	 * Returns the start year of the series. 
	 * @return String
	 */
	public String getSeriesStartYear()
	{
		return seriesStartYear;
	}
	
	/**
	 * Returns the duration of the series.
	 * @return String
	 */
	public String getSeriesDuration()
	{
		return seriesDuration;
	}
	
	/**
	 * Returns the String form of the fields in a Series object.
	 * @return String
	 */
	public String toString()
	{
		String createdString = "Series Title: " + seriesTitle + "Series Start Year: " + seriesStartYear + "series Duration: " + seriesDuration;
		
		return createdString;
	}
	
	
}
