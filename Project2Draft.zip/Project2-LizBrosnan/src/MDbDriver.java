import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * CS 2334
 * Project 2
 * 2/19/2016
 * @author Liz Brosnan
 * 
 * This is the driver class for Project 2. 
 *
 */
public class MDbDriver implements Comparable 
{
	/** This variable holds the user input. */
	public static String userInput;
	
	/** This variable hold the movie found for user. */
	public static Movie foundMovie;
	
	/** This variable holds the series found for the user. */
	public static Series foundSeries;
	
	/** This variable will store both series and movie objects. */
	public static List mediaData;
	
	/**
	 * Parses the movie file data
	 * @param movieFile
	 * @return List Movie objects have been added to
	 */
	public static List parseMovieFileData(ArrayList<String> movieFile)
	{
		return null;
	}
	
	
	
	
	
	/**
	 * Parses the series file data.
	 * @param SeriesFile
	 * @return List Series objects have been added to
	 */
	public static List parseSeriesFileData(ArrayList<String> SeriesFile)
	{
		return null;
	}
	
	public static Object searchMedia(String userInput)
	{
		return null;
	}
	
	
	
	
	public static void sortMedia(List mediaData)
	{
		
	}
	
	
	
	
	@override
	public int compareTo(Object mediaObj1)
	{
		int placeHolder = 1;
		return placeHolder;
	}
	
	public static void main(String[] args)
	{
		
	}


}

