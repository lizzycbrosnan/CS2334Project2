/**
 * CS 2334 
 * Project 2
 * 2/19/2016
 * @author Liz Brosnan
 * 
 * This is a class that will store information on Movie objects. 
 *
 */
public class Movie {
	/** stores the title of the movie */
	public String movieTitle; 
	
	/** stores a movie's version, if it has more than one version for a particular year */
	public String movieVersion;
	
	/** stores whether the movie was released on TV, video, theaters, etc */
	public String movieReleaseLocation; 
	
	/** stores the concrete date of release for the movie */
	public String movieReleaseDate; 
	
	
	/**
	 * @param movieTitle	The title of the movie
	 * @param movieVersion	The version of the movie
	 * @param movieReleaseLocation	The release location of the movie
	 * @param movieReleaseDate	The release date of the movie
	 * 
	 * This is a constructor to create a movie object with all 4 fields pre-defined. 
	 */
	public Movie(String movieTitle, String movieVersion, String movieReleaseLocation, String movieReleaseDate)
	{
		this.movieTitle = movieTitle;
		this.movieVersion = movieVersion;
		this.movieReleaseLocation = movieReleaseLocation;
		this.movieReleaseDate = movieReleaseDate; 
	}
	
	/**
	 * This is an auto-constructor, that sets all fields in Movie class equal to the empty String, until 
	 * they can be defined. 
	 */
	
	public Movie()
	{
		this.movieTitle = "";
		this.movieVersion = ""; 
		this.movieReleaseLocation = "";
		this.movieReleaseDate = "";
	}
	
	/** 
	 * 
	 * @param String	The title of the movie
	 * This method sets the movie title of a Movie object equal to a String passed as an 
	 * argument.
	 */
	
	public void setMovieTitle(String title)
	{
		this.movieTitle = title;
	}
	
	/**
	 * 
	 * @param String	The version of the movie
	 * This method sets the movie version of a Movie object equal to a String passed as an
	 * argument.
	 */
	
	public void setMovieVersion(String version)
	{
		this.movieVersion = version;
	}
	
	/**
	 * 
	 * @param String	The release location of the movie
	 * This method sets the release location of a Movie object equal to a String passed as an
	 * argument.
	 */
	
	public void setMovieReleaseLocation(String location)
	{
		this.movieReleaseLocation = location;
	}
	
	/**
	 * 
	 * @param String	The date of release of the movie
	 * This method sets the release date of a Movie object equal to a String passed as an 
	 * argument.
	 */
	
	public void setMovieReleaseDate(String date)
	{
		this.movieReleaseDate = date;
	}
	
	/**
	 * 
	 * @return String	The movie title
	 * This method will return the title of a specific, given reference to a Movie object
	 * as an argument.
	 */
	
	public String getMovieTitle()
	{
		return movieTitle;
	}
	
	
	/** 
	 * 
	 * @return String	The movie version
	 * This method will return the version of a specific, given reference to a Movie object
	 * as an argument.
	 */
	
	public String getMovieVersion()
	{
		return movieVersion;
	}
	
	/**
	 * 
	 * @return String	The release location of the movie
	 * This method will return the release location of a specific, given reference to a Movie 
	 * object as an argument.
	 */
	
	public String getMovieReleaseLocation()
	{
		return movieReleaseLocation;
	}
	
	/**
	 *
	 * @return String	The release date of the movie
	 * This method will return the release date of a specific, given reference to a Movie object
	 * as an argument.
	 */
	
	public String getMovieReleaseDate()
	{
		return movieReleaseDate;
	}
	
	/**
	 * 
	 * @return String	The string version of the information/fields of requested movie object
	 * This method will return a String of Movie info, and serves the purpose of 
	 * converting the Movie object info found for the user into something that can be output. 
	 */
	
	public String toString()
	{
		String createdString = "Movie Title: " + movieTitle + " Movie Version: " + movieVersion + " Movie Release Location: " + movieReleaseLocation + " Movie Release Date: " + movieReleaseDate;
		
		return createdString;
	}
	
	
}