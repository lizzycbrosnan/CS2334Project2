import java.util.Comparator;

/**
 * CS 2334
 * Project 2
 * 2/19/2016
 * @author Liz Brosnan
 * 
 * This class holds the compare method for years of media types. 
 *
 */
public class YearComparator implements Comparator {

	/**
	 * @param 2 objects you wish to compare
	 * @return int, the result of the comparison
	 */
	public int compare(Object mediaObj1, Object mediaObj2)
	{
		int placeHolder = 1;
		return placeHolder;
	}
}
