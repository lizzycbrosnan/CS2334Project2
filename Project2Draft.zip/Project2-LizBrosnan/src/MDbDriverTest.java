import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class MDbDriverTest {

	@Test
	public void testParseMovieFileData() {
		fail("Not yet implemented");
		
		String sampleFileLine = new String("Toy Story (1999/I) (TV) 1999"); 
		
		ArrayList<String> sampleFileData = new ArrayList<String>();
		
		sampleFileData.add(sampleFileLine);
		
		List testMovies = new ArrayList<Movie>();
		
		testMovies = MDbDriver.parseMovieFileData(sampleFileData);
		
		assertEquals("Toy Story", ((Movie) testMovies.get(0)).getMovieTitle());
		
		assertEquals("1999/I", ((Movie) testMovies.get(0)).getMovieVersion());
		
		assertEquals("TV", ((Movie) testMovies.get(0)).getMovieReleaseLocation());
		
		assertEquals("1999", ((Movie) testMovies.get(0)).getMovieReleaseDate());
	}
	
	@Test
	public void testParseSeriesFileData() {
		fail("Not yet implemented");
		
		String sampleFileLine = new String("Doctor Who 1963 A Bargain of Necessity (#1.41)} 1964");
		
		ArrayList<String> sampleFileData = new ArrayList<String>();
		
		sampleFileData.add(sampleFileLine);
		
		List testSeries = new ArrayList<Series>();
		
		testSeries = MDbDriver.parseSeriesFileData(sampleFileData);
		
		assertEquals("Doctor Who", ((Series) testSeries.get(0)).getSeriesTitle());
		
		assertEquals("1963", ((Series) testSeries.get(0)).getSeriesStartYear());
		
	}
	
	@Test
	
	public void testSortMedia()
	{
		fail("Not yet implemented");
		
		List mediaData = new ArrayList<Object>();
		
		Movie sampleMovie = new Movie();
		
		sampleMovie.setMovieTitle("Shrek");
		
		Movie sampleMovie2 = new Movie();
		
		sampleMovie.setMovieTitle("Finding Nemo");
		
		mediaData.add(sampleMovie);
		
		mediaData.add(sampleMovie2);
		
		MDbDriver.sortMedia(mediaData);
		
		assertEquals("Finding Nemo", mediaData.get(0));
		
	}
	
	@Test
	
	public void testSearchMedia()
	{
		fail("Not yet implemented");
		
		List mediaData = new ArrayList<Object>();
		
		Movie sampleMovie = new Movie("Toy Story", "1999/I", "TV", "1999");
		
		Movie foundMovie = new Movie(); 
		
		String userInput = "Toy Story";
		
		foundMovie = (Movie) MDbDriver.searchMedia(userInput);
		
		assertEquals(foundMovie.getMovieTitle(), userInput);
		
		
	}

}
