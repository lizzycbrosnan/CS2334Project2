/**
 * CS 2334
 * Project 2 
 * 2/19/2016
 * @author Liz Brosnan
 * 
 * This is a class that will store information about a particular episode of a specific show.
 *
 */
public class Episode {
	
	/** This variable stores the title of the episode. */
	public String episodeTitle;
	
	/** This variable stores the episode number. */
	public String episodeNumber;
	
	/** This variable stores the season number the episode belongs to. */
	public String seasonNumber;
	
	/** This variable stores the year the episode first aired. */ 
	public String yearOfEpisode;
	
	/** General constructor for an episode object. */ 
	public Episode()
	{
		this.episodeTitle = "";
		this.episodeNumber = "";
		this.seasonNumber = ""; 
		this.yearOfEpisode = "";
		
	}
	
	/** Constructor for episode object with fields already defined. */
	public Episode (String episodeTitle, String episodeNumber, String seasonNumber, String yearOfEpisode)
	{
		this.episodeTitle = episodeTitle;
		this.episodeNumber = episodeNumber;
		this.seasonNumber = seasonNumber;
		this.yearOfEpisode = yearOfEpisode;
	}
	
	/**
	 * Sets title of episode. 
	 * @param episodeTitle
	 */
	public void setEpisodeTitle(String episodeTitle)
	{
		this.episodeTitle = episodeTitle;
	}
	
	/**
	 * Sets episode number of episode. 
	 * @param episodeNumber
	 */
	public void setEpisodeNumber(String episodeNumber)
	{
		this.episodeNumber = episodeNumber;
	}
	
	/**
	 * Sets season number of episode.
	 * @param seasonNumber
	 */
	public void setSeasonNumber(String seasonNumber)
	{
		this.seasonNumber = seasonNumber;
	}
	
	/**
	 * Sets year of the episode.
	 * @param yearOfEpisode
	 */
	public void setYearOfEpisode(String yearOfEpisode)
	{
		this.yearOfEpisode = yearOfEpisode;
	}
	
	/**
	 * Returns the episode title.
	 * @return String
	 */
	public String getEpisodeTitle()
	{
		return episodeTitle;
	}
	
	/**
	 * Returns the episode number.
	 * @return String
	 */
	public String getEpisodeNumber()
	{
		return episodeNumber;
	}
	
	/**
	 * Returns the season number the episode belongs to.
	 * @return
	 */
	public String getSeasonNumber()
	{
		return seasonNumber;
	}
	
	/** Returns the year the episode first aired. */
	public String getYearOfEpidode()
	{
		return yearOfEpisode;
	}
	
	/** toString method that returns String version of episode info. */
	public String toString()
	{
		String createdString;
		
		createdString = "Episode Title: " + episodeTitle + " Episode Number: " + episodeNumber + " Season Number: " + seasonNumber + "Year of Episode: " + yearOfEpisode;
		
		return createdString;
	}
	
}
